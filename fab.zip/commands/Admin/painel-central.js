const { ApplicationCommandType, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require("discord.js");
const config = require("../../config.json");

module.exports = {
    name: "painel-central",
    description: "[🤖] Execute o Comando de Painel de central",
    type: ApplicationCommandType.ChatInput, 
    run: async (client, interaction) => {
        if (!interaction.member.roles.cache.has(config.cargos_padroes.role_staff)) {
            return interaction.reply({ content: `❌ | Você não possui permissão para usar esse comando.`, ephemeral: true });
        }

        await interaction.reply({ content: `<a:nexus_loading:1203010429526343850> Enviando Painel`, ephemeral: true });

        const embed = new EmbedBuilder()
            .setTitle(`Painel Central - ${interaction.guild.name}`)
            .setDescription("> A partir do sistema de central de funcionalidades, é possível acessar as funcionalidades adicionais do sistema, as quais estão disponíveis através do menu a seguir\n\n- Sistema de gestão de ausências, exclusivo para membros em geral, no qual é necessário inserir o motivo e a data a partir do dia seguinte.\n\n- Sistema de registro de advertências, que é exclusivo para os responsáveis designados.")
            .setColor(`#2f3136`);

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('centralselect')
            .setPlaceholder('Selecione uma funcionalidade:')
            .addOptions([
                {
                    label: 'Gestão de Ausências',
                    emoji: '<:1165773629166997574:1211727578390335558>',
                    description: 'Acesse o sistema de gestão de ausências.',
                    value: 'ausencia',
                },
                {
                    label: 'Registro de Advertências',
                    emoji: '<:1165773632644067478:1211727479484448799>',
                    description: 'Acesse o sistema de registro de advertências.',
                    value: 'adv',
                },
            ]);

        const row = new ActionRowBuilder()
            .addComponents(selectMenu);

        await interaction.channel.send({
            embeds: [embed],
            components: [row]
        });

        await interaction.editReply({ content: "✅ | Painel enviado com sucesso" });
    }
}
