const { ApplicationCommandType, ButtonBuilder, ActionRowBuilder, EmbedBuilder } = require("discord.js");
const config = require("../../config.json");

module.exports = {
    name: "painel-registro",
    description: "[🤖] Execute o Comando de Painel de Registro",
    type: ApplicationCommandType.ChatInput,
    run: async (client, interaction) => {
        if (!interaction.member.roles.cache.has(config.cargos_padroes.role_staff)) {
            return interaction.reply({ content: `Apenas Staff's pode executar este comando!`, ephemeral: true });
        }

        await interaction.reply({ content: `<a:nexus_loading:1203010429526343850> Preparando para enviar o painel...`, ephemeral: true });

        const embed = new EmbedBuilder()
            .setTitle(`REGISTRO - ${interaction.guild.name}`)
            .setDescription(`
Seja muito bem-vindo(a) á **${interaction.guild.name}.** A partir deste momento, solicitamos a gentileza de realizar um registro em nosso sistema.
Trata-se de um procedimento rápido em que solicitamos que responda algumas perguntas.
Para iniciar, por favor, clique no botão "REGISTRAR-SE".


Agradecemos desde já pela sua colaboração.`)
            .setColor(`#2f3136`) 
            .setTimestamp()

        await interaction.channel.send({
            embeds: [embed],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("register")
                        .setLabel("REGISTRAR-SE")
                        .setStyle(3)
                ),
            ],
        }).then(() => {
            interaction.editReply({ content: "Painel Enviado com sucesso" });
        });
    },
};
