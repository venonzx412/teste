const { ModalBuilder, TextInputBuilder, ActionRowBuilder, ButtonBuilder, EmbedBuilder, StringSelectMenuBuilder } = require("discord.js");
const config = require("../../config.json");
const { QuickDB } = require("quick.db");
const users = new QuickDB({ table: "users" });
const ids = new QuickDB({ table: "ids" });

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {
        if (interaction.isStringSelectMenu()) {
            const { customId } = interaction;
            if (customId === "centralselect") {
                const options = interaction.values[0];

                if (options === "ausencia") {
                    if (!interaction.member.roles.cache.has(config.cargos_padroes.role_tag)) {
                        return interaction.reply({ content: `<:aviso:1203010580278022175> Apenas quem tem o cargo: <@&${config.cargos_padroes.role_tag}> pode usar!`, ephemeral: true });
                    }

                    const modal = new ModalBuilder()
                        .setCustomId("ausencia_modal")
                        .setTitle("AUSÊNCIA");

                    const motivoInput = new TextInputBuilder()
                        .setCustomId("motivo")
                        .setLabel("MOTIVO:")
                        .setRequired(true)
                        .setMaxLength(40)
                        .setStyle(1);

                    const dataInput = new TextInputBuilder()
                        .setCustomId("data_encerramento")
                        .setLabel("QUAL A DATA DE ENCERRAMENTO?")
                        .setRequired(true)
                        .setPlaceholder("DD/MM/YYYY")
                        .setMaxLength(10)
                        .setMinLength(9)
                        .setStyle(1);

                    modal.addComponents(new ActionRowBuilder().addComponents(motivoInput));
                    modal.addComponents(new ActionRowBuilder().addComponents(dataInput));

                    return interaction.showModal(modal);
                }

                if (options === "adv") {
                    if (!interaction.member.roles.cache.has(config.cargos_padroes.role_staff)) {
                        return interaction.reply({ content: `<:aviso:1203010580278022175> Apenas quem tem o cargo: <@&${config.cargos_padroes.role_staff}> pode usar!`, ephemeral: true });
                    }

                    const modal = new ModalBuilder()
                        .setCustomId("adv_modal")
                        .setTitle("ADVERTÊNCIA");

                    const userIdInput = new TextInputBuilder()
                        .setCustomId("id_usuario")
                        .setLabel("ID DO USUÁRIO:")
                        .setRequired(true)
                        .setMaxLength(40)
                        .setStyle(1);

                    const motivoInput = new TextInputBuilder()
                        .setCustomId("motivo")
                        .setLabel("MOTIVO:")
                        .setRequired(true)
                        .setMaxLength(25)
                        .setStyle(1);

                    const dataInput = new TextInputBuilder()
                        .setCustomId("data_encerramento")
                        .setLabel("QUAL A DATA DE ENCERRAMENTO?")
                        .setRequired(true)
                        .setPlaceholder("DD/MM/YYYY")
                        .setMaxLength(10)
                        .setMinLength(9)
                        .setStyle(1);

                    modal.addComponents(new ActionRowBuilder().addComponents(userIdInput));
                    modal.addComponents(new ActionRowBuilder().addComponents(motivoInput));
                    modal.addComponents(new ActionRowBuilder().addComponents(dataInput));

                    return interaction.showModal(modal);
                }
            }
        }

        if (interaction.isModalSubmit()) {
            const { customId } = interaction;

            if (customId === "adv_modal") {
                const idUser = interaction.fields.getTextInputValue("id_usuario");
                const data = interaction.fields.getTextInputValue("data_encerramento");
                const motivo = interaction.fields.getTextInputValue("motivo");
                const member = interaction.guild.members.cache.get(idUser);

                if (!member) {
                    return interaction.reply({ content: `<:aviso:1203010580278022175> O Usuario que você colocou não está no servidor!`, ephemeral: true });
                }

                if (!member.roles.cache.has(config.cargos_padroes.role_tag)) {
                    return interaction.reply({ content: `<:aviso:1203010580278022175> Apenas quem tem o cargo: <@&${config.cargos_padroes.role_tag}> pode ser advertido`, ephemeral: true });
                }

                if (!validarData(data)) {
                    return interaction.reply({ content: `<:aviso:1203010580278022175> Coloque uma data valida ou acima do dia atual!`, ephemeral: true });
                }

                await interaction.reply({
                    content: `> <:User:1211728314901995572> **RESPONSÁVEL:** ${interaction.user} \n> <:user:1211728439128752171>** Membro:** ${member} \n> <:calendario1:1211728471987064952> **DATA FINAL:** ${data} \n> <:Informacao:1210615926035054692> ** MOTIVO:** ${motivo} \n\n- *Selecione abaixo a advertência*`,
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new StringSelectMenuBuilder()
                                    .setCustomId(`${data}_${idUser}_${motivo}_aselect`)
                                    .setPlaceholder("Selecione a advertência")
                                    .addOptions(
                                        {
                                            label: "Advertência leve",
                                            description: "O membro apenas recebera cargo de advertência.",
                                            emoji: "🚫",
                                            value: "adv_leve"
                                        },
                                        {
                                            label: "Advertência média",
                                            description: "O membro é rebaixado um cargo.",
                                            emoji: "🚫",
                                            value: "adv_medio"
                                        },
                                        {
                                            label: "Advertência grave",
                                            description: "O membro é banido do servidor.",
                                            emoji: "🚫",
                                            value: "adv_grave"
                                        }
                                    )
                            )
                    ],
                    ephemeral: true
                });
            }

            if (customId === "ausencia_modal") {
                const motivo = interaction.fields.getTextInputValue("motivo");
                const data = interaction.fields.getTextInputValue("data_encerramento");

                if (!validarData(data)) {
                    return interaction.reply({ content: `<:aviso:1203010580278022175> Coloque uma data Valida ou acima de hoje!`, ephemeral: true });
                }

                await interaction.reply({ content: `<:aviso:1203010580278022175> Ausência enviada com sucesso!`, ephemeral: true });

                const channel = await interaction.guild.channels.cache.get(config.canais.ausencia);

                if (channel) {
                    channel.send({
                        content: `
<:User:1211728314901995572> **MEMBRO:** ${interaction.user}
<:exclamar:1210614097092022353> **MOTIVO:** ${motivo}
<:calendario1:1211728471987064952> **FIM DA AUSÊNCIA:** ${data}`,
                        components: [
                            new ActionRowBuilder()
                                .addComponents(
                                    new ButtonBuilder()
                                        .setCustomId(`${interaction.user.id}_${data}_${motivo}_removerausencia`)
                                        .setLabel("REMOVER AUSÊNCIA")
                                        .setStyle(1)
                                )
                        ]
                    });
                }
            }
        }

        if (interaction.isStringSelectMenu() && interaction.customId.endsWith("_aselect")) {
            const [data, idUser, motivo] = interaction.customId.split("_");
            const options = interaction.values[0];
            const member = interaction.guild.members.cache.get(idUser);

            await users.add(`${idUser}.adv`, 1);

            if (options === "adv_medio") {
                interaction.update({
                    content: `<:certo:1203010683180941433>  Você advertiu com sucesso e o membro ganhou o cargo: <@&${config.cargos_registros.advertencias.adv2}>`,
                    components: []
                });

                await member.roles.add(config.cargos_registros.advertencias.adv2).catch(() => { console.log("Sem Permissão") });

                const channel = interaction.guild.channels.cache.get(config.canais.advertidos);
                if (channel) {
                    channel.send({
                        content: `
<:user:1211728439128752171> **ADVERTIDO:** <@${idUser}>
<:1165773632644067478:1211727479484448799> **ADVERTÊNCIA:** <@&${config.cargos_registros.advertencias.adv2}>
<:exclamar:1210614097092022353> **MOTIVO:** ${motivo}
<:calendario1:1211728471987064952> **DURAÇÃO:** ${data}`,
                        components: [
                            new ActionRowBuilder()
                                .addComponents(
                                    new ButtonBuilder()
                                        .setCustomId(`${idUser}_medio_removeradv`)
                                        .setLabel("REMOVER ADVERTÊNCIA")
                                        .setStyle(2),
                                    new ButtonBuilder()
                                        .setCustomId(`${idUser}_verquantidadeadv`)
                                        .setEmoji("<:imp_ferrament:1246683691946737774>")
                                        .setStyle(1)
                                )
                        ]
                    });
                }

                await handleRoleAdjustment(interaction, member, "medio");
            }

            if (options === "adv_leve") {
                interaction.update({
                    content: `<:certo:1203010683180941433>  Você advertiu com sucesso e o membro ganhou o cargo: <@&${config.cargos_registros.advertencias.adv1}>`,
                    components: []
                });

                await member.roles.add(config.cargos_registros.advertencias.adv1).catch(() => { console.log("Sem Permissão") });

                const channel = interaction.guild.channels.cache.get(config.canais.advertidos);
                if (channel) {
                    channel.send({
                        content: `
<:user:1211728439128752171> **ADVERTIDO:** <@${idUser}>
<:1165773632644067478:1211727479484448799> **ADVERTÊNCIA:** <@&${config.cargos_registros.advertencias.adv1}>
<:exclamar:1210614097092022353> **MOTIVO:** ${motivo}
<:calendario1:1211728471987064952> **DURAÇÃO:** ${data}`,
                        components: [
                            new ActionRowBuilder()
                                .addComponents(
                                    new ButtonBuilder()
                                        .setCustomId(`${idUser}_leve_removeradv`)
                                        .setLabel("REMOVER ADVERTÊNCIA")
                                        .setStyle(2),
                                    new ButtonBuilder()
                                        .setCustomId(`${idUser}_verquantidadeadv`)
                                        .setEmoji("<:imp_ferrament:1246683691946737774>")
                                        .setStyle(1)
                                )
                        ]
                    });
                }
            }

            if (options === "adv_grave") {
                interaction.update({
                    content: `<:certo:1203010683180941433>  Você advertiu com sucesso e o membro foi banido do servidor!`,
                    components: []
                });

                const channel = interaction.guild.channels.cache.get(config.canais.advertidos);
                if (channel) {
                    channel.send({
                        content: `
<:user:1211728439128752171> **ADVERTIDO:** <@${idUser}>
<:1165773632644067478:1211727479484448799> **ADVERTÊNCIA:** BANIDO
<:exclamar:1210614097092022353> **MOTIVO:** ${motivo}
<:calendario1:1211728471987064952> **DURAÇÃO:** ${data}`
                    });
                }

                member.ban({ reason: `${motivo}` });
            }
        }

        if (interaction.isButton()) {
            const customIdParts = interaction.customId.split("_");

            if (customIdParts.includes("removeradv")) {
                if (!interaction.member.roles.cache.has(config.cargos_padroes.role_staff)) return interaction.reply({content:`❌ | Você não possui permissão para executar essa ação.`, ephemeral:true});
                const [idUser, severity] = customIdParts;
                const member = interaction.guild.members.cache.get(idUser);

                if (!member) {
                    return interaction.reply({ content: "O usuário não está mais no servidor.", ephemeral: true });
                }

                let roleId;
                switch (severity) {
                    case "leve":
                        roleId = config.cargos_registros.advertencias.adv1;
                        break;
                    case "medio":
                        roleId = config.cargos_registros.advertencias.adv2;
                        break;
                    // Add other severities if needed
                }

                if (roleId) {
                    await member.roles.remove(roleId).catch(() => { console.log("Sem Permissão") });
                    await users.sub(`${idUser}.adv`, 1);
                }

                interaction.update({ content: `<:certo:1203010683180941433> A advertência foi removida com sucesso!`, components: [] });
            }

            if (customIdParts.includes("verquantidadeadv")) {
                const idUser = customIdParts[0];
                const advCount = await users.get(`${idUser}.adv`);
                return interaction.reply({ content: `O usuário <@${idUser}> tem ${advCount} advertências.`, ephemeral: true });
            }

            if (customIdParts.includes("removerausencia")) {
                const [userId, data, motivo] = interaction.customId.split("_");
                const member = interaction.guild.members.cache.get(userId);

                if (interaction.user.id !== userId) return interaction.reply({ content: `<:aviso:1203010580278022175> Apenas o Usuario <@${userId}> pode remover esta ausência!`, ephemeral: true });

                if (!member) {
                    return interaction.reply({ content: "O usuário não está mais no servidor.", ephemeral: true });
                }

                const absenceChannel = interaction.guild.channels.cache.get(config.canais.logs_ausencia);

                await interaction.update({
                    content: `<:certo:1203010683180941433> A ausência foi removida com sucesso!`,
                    components: []
                });

                absenceChannel.send(`
<:user:1211728439128752171> **A AUSÊNCIA DO USUARIO** <@${userId}> **FOI REMOVIDA**
<a:positivo:1211731549209497630> **SUPERIOR QUE REMOVEU A AUSÊNCIA:** ${interaction.user}`);
            }
        }
    }
};

function validarData(data) {
    const [dia, mes, ano] = data.split('/');
    const dataAtual = new Date();
    const dataInput = new Date(`${ano}-${mes}-${dia}`);
    return dataInput > dataAtual;
}

async function handleRoleAdjustment(interaction, member, severity) {
    const cargos = config.cargos_staff; // Assuming cargos_staff is an array of role IDs from highest to lowest.

    for (let i = 0; i < cargos.length; i++) {
        if (member.roles.cache.has(cargos[i])) {
            await member.roles.remove(cargos[i]).catch(() => { console.log("Erro ao remover cargo") });
            if (severity === "medio" && i + 1 < cargos.length) {
                await member.roles.add(cargos[i + 1]).catch(() => { console.log("Erro ao adicionar cargo") });
            }
            break;
        }
    }
}
