const { ModalBuilder, TextInputBuilder, ActionRowBuilder } = require("discord.js");
const config = require("../../config.json");
const { QuickDB } = require("quick.db");
const users = new QuickDB({table:"users"});
const count = new QuickDB({table:"contador"});
const ids = new QuickDB({table:"ids"});
const moment = require("moment")



module.exports = {
    name:"interactionCreate", 
    run: async( interaction, client) => {
        if(interaction.isButton()) {
            const {customId} = interaction;
            if(customId === "register") {
                if (!interaction.member.roles.cache.has(config.cargos_padroes.role_noregister)) return interaction.reply({content:`<:aviso:1203010580278022175>〢Você precisa do cargo <@&${config.cargos_padroes.role_noregister}> para se registrar.`, ephemeral:true});
                const modal = new ModalBuilder()
                .setCustomId("register_modal")
                .setTitle("REGISTRO");

                const text = new TextInputBuilder()
                .setCustomId("text")
                .setLabel("QUAL É O SEU ID NO JOGO?")
                .setStyle(1)
                .setRequired(true);

                const text1 = new TextInputBuilder()
                .setCustomId("text1")
                .setLabel("QUAL É O SEU NICK?")
                .setStyle(1)
                .setRequired(true);


                modal.addComponents(new ActionRowBuilder().addComponents(text));
                modal.addComponents(new ActionRowBuilder().addComponents(text1));

                return interaction.showModal(modal);
            }
        }
        if(interaction.isModalSubmit()) {
            const {customId} = interaction;
            if(customId === "register_modal") {
                const id = interaction.fields.getTextInputValue("text");
                const nick = interaction.fields.getTextInputValue("text1");
                const ide = await ids.get(`${id}`);
                if(ide) return interaction.reply({content:`<:aviso:1203010580278022175>〢O ID \`${id}\` já está registrado no banco de dados.`, ephemeral:true});
                await interaction.reply({content:`<:certo:1203010683180941433>〢Você se registrou com sucesso utilizando o ID \`${id}\``, ephemeral:true});
                await count.add("numeros", 1);
                await ids.set(`${id}`, interaction.user.id);
                await users.set(`${interaction.user.id}`, {
                    id: id,
                    nick: nick,
                    adv: 0,
                    cargo: "menor",
                });
                await interaction.member.setNickname(`${nick} - ${id}`).catch(() => {console.log("Não tenho permissão.")});
                await interaction.member.roles.remove(config.cargos_padroes.role_noregister);
                await interaction.member.roles.add(config.cargos_padroes.role_tag);
                const channel = await interaction.guild.channels.cache.get(config.canais.logs_registro);
                if(channel) {
                    channel.send({content:`
<:emojiedit:1203016241204428860> **MEMBRO:** ${interaction.user}
<:id:1203011860048117853> **ID:** ${id}
<a:Loading:1203011902930686073> **REGISTRO ENVIADO HÁ:** <t:${moment(interaction.createdTimestamp).unix()}>(<t:${parseInt(interaction.createdTimestamp / 1000)}:R>)`})
                }

            }
        }
    }
}