const {Client , GatewayIntentBits,Collection, Partials } = require("discord.js");
const { ActivityType} = require('discord.js');
console.clear()

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping
    ],
    partials: [
        Partials.Message,
        Partials.Channel
    ]
  });
// Função para formatar o tempo de atividade em dias, horas, minutos e segundos
function formatUptime(uptime) {
  const days = Math.floor(uptime / (3600 * 24));
  const hours = Math.floor((uptime % (3600 * 24)) / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = Math.floor(uptime % 60);
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

let activities = [
  `💙 FAB`,
  `🟢 Estou online e operando há: ${formatUptime(process.uptime())}`,
  `🏆 Criado e desenvolvido por: solitude27`
];
let i = 0;
setInterval(() => {
  client.user.setPresence({
      activities: [{ name: `${activities[i++ % activities.length]}`, type: ActivityType.Playing }],
      status: 'online',
  });
}, 4000);


module.exports = client;
client.slashCommands = new Collection();
const {token} = require("./token.json");
client.login(token);
const evento = require("./handler/Events");
evento.run(client);
require("./handler/index")(client);

process.on('unhandRejection', (reason, promise) => {
    console.log(`🚫 Erro Detectado:\n\n` + reason, promise)
});
process.on('uncaughtException', (error, origin) => {
  console.log(`🚫 Erro Detectado:\n\n` + error, origin)  
});
